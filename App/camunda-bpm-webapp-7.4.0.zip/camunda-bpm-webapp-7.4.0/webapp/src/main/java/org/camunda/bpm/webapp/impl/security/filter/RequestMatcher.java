/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.camunda.bpm.webapp.impl.security.filter;

import java.util.Map;

/**
 *
 * @author nico.rehwaldt
 */
public class RequestMatcher {

  private final RequestFilter filter;
  private final RequestAuthorizer authorizer;

  public RequestMatcher(RequestFilter filter, RequestAuthorizer authorizer) {
    this.filter = filter;
    this.authorizer = authorizer;
  }

  public Match match(String requestMethod, String requestUri) {
    Map<String, String> match = filter.match(requestMethod, requestUri);

    if (match != null) {
      return new Match(match, authorizer);
    } else {
      return null;
    }
  }

  public static class Match {

    private final Map<String, String> parameters;
    private final RequestAuthorizer authorizer;

    public Match(Map<String, String> parameters, RequestAuthorizer authorizer) {
      this.parameters = parameters;
      this.authorizer = authorizer;
    }

    public Authorization authorize() {
      return authorizer.authorize(parameters);
    }
  }
}
