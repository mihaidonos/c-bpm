'use strict';

describe('Cockpit page header Spec', require('../../commons/pages/header-spec-defintion')('Cockpit'));
