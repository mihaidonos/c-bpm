'use strict';

describe('Admin page header Spec', require('../../commons/pages/header-spec-defintion')('Admin'));
