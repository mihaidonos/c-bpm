'use strict';

var Page = require('../base');

module.exports = Page.extend({

  url: '/camunda/app/cockpit/default/#/repository'

});
