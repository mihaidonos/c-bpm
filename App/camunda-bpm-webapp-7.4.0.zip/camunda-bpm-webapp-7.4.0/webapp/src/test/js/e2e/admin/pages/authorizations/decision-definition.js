'use strict';

var Page = require('./authorizations-base');

module.exports = Page.extend({

  url: '/camunda/app/admin/default/#/authorization?resource=10'

});
